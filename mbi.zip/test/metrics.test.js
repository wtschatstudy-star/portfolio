// Unit tests for Haugen Engine metrics

import { StructuralEngine } from '../engines/structural.js';
import { EnvironmentEngine } from '../engines/environment.js';
import { ExecutionEngine } from '../engines/execution.js';
import { OperatorEngine } from '../engines/operator.js';

// Mock candle data
function generateMockCandles(count = 50) {
  const candles = [];
  let currentPrice = 42500;
  
  for (let i = 0; i < count; i++) {
    const change = (Math.random() - 0.5) * 100;
    const open = currentPrice;
    const close = currentPrice + change;
    const high = Math.max(open, close) + Math.abs(Math.random() * 50);
    const low = Math.min(open, close) - Math.abs(Math.random() * 50);
    const volume = Math.floor(Math.random() * 1000000);
    
    candles.push({
      timestamp: Date.now() + i * 60000,
      open,
      high,
      low,
      close,
      volume
    });
    
    currentPrice = close;
  }
  
  return candles;
}

// Test runner
function runTests() {
  console.log('Starting unit tests...\n');
  
  let passed = 0;
  let failed = 0;

  // Test Structural Engine
  console.log('=== STRUCTURAL ENGINE TESTS ===');
  const structuralEngine = new StructuralEngine();
  const candles = generateMockCandles(50);
  
  try {
    structuralEngine.update(candles);
    console.assert(typeof structuralEngine.beyfo === 'number', 'BEYFO should be a number');
    console.assert(structuralEngine.beyfo >= 0 && structuralEngine.beyfo <= 100, 'BEYFO should be 0-100');
    console.assert(typeof structuralEngine.drift === 'number', 'Drift should be a number');
    console.log('✓ Structural Engine initialized correctly');
    passed++;
  } catch (e) {
    console.error('✗ Structural Engine test failed:', e.message);
    failed++;
  }

  // Test Environment Engine
  console.log('\n=== ENVIRONMENT ENGINE TESTS ===');
  const envEngine = new EnvironmentEngine();
  
  try {
    envEngine.update(candles);
    console.assert(typeof envEngine.liquidity === 'number', 'Liquidity should be a number');
    console.assert(envEngine.liquidity >= 0, 'Liquidity should be non-negative');
    console.assert(typeof envEngine.volatility === 'number', 'Volatility should be a number');
    console.log('✓ Environment Engine initialized correctly');
    passed++;
  } catch (e) {
    console.error('✗ Environment Engine test failed:', e.message);
    failed++;
  }

  // Test Execution Engine
  console.log('\n=== EXECUTION ENGINE TESTS ===');
  const execEngine = new ExecutionEngine();
  
  try {
    execEngine.update(candles);
    console.assert(typeof execEngine.bias === 'number', 'Bias should be a number');
    console.assert(execEngine.bias >= -0.5 && execEngine.bias <= 0.5, 'Bias should be -0.5 to 0.5');
    console.assert(typeof execEngine.rsi === 'number', 'RSI should be a number');
    console.assert(execEngine.rsi >= 0 && execEngine.rsi <= 100, 'RSI should be 0-100');
    console.log('✓ Execution Engine initialized correctly');
    passed++;
  } catch (e) {
    console.error('✗ Execution Engine test failed:', e.message);
    failed++;
  }

  // Test Operator Engine
  console.log('\n=== OPERATOR ENGINE TESTS ===');
  const opEngine = new OperatorEngine();
  
  try {
    opEngine.update(candles);
    console.assert(typeof opEngine.state === 'string', 'State should be a string');
    console.assert(['IDLE', 'ACTIVE'].includes(opEngine.state), 'State should be IDLE or ACTIVE');
    console.assert(typeof opEngine.permission === 'string', 'Permission should be a string');
    console.log('✓ Operator Engine initialized correctly');
    passed++;
  } catch (e) {
    console.error('✗ Operator Engine test failed:', e.message);
    failed++;
  }

  // Summary
  console.log('\n=== TEST SUMMARY ===');
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total: ${passed + failed}`);

  return failed === 0;
}

// Run tests if this file is executed directly
if (typeof process !== 'undefined' && process.argv[1].includes('metrics.test.js')) {
  runTests();
}

export { runTests, generateMockCandles };
