export class Scales {
  constructor() {
    this.min = 0;
    this.max = 1;
  }

  updateScales(candles) {
    if (candles.length === 0) return;

    let min = Infinity;
    let max = -Infinity;

    for (const c of candles) {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    }

    this.min = min;
    this.max = max;
  }

  priceToY(price, height) {
    const range = this.max - this.min || 1;
    return height - ((price - this.min) / range) * height;
  }
}
