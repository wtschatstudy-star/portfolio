export class Viewport {
  constructor() {
    this.offset = 0;
  }

  fitCandles(candles, width) {
    const maxVisible = Math.floor(width / 8);
    this.offset = Math.max(0, candles.length - maxVisible);
  }

  autoScrollToLatest(candles) {
    this.offset = Math.max(0, candles.length - 200);
  }

  update(delta) {
    // Reserved for smooth scroll / inertia if needed
  }

  getVisibleCandles(candles) {
    return candles.slice(this.offset);
  }
}
