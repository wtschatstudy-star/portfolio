export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function aggregateCandles(candles, targetCount) {
  if (candles.length <= targetCount) return candles;
  
  const groupSize = Math.ceil(candles.length / targetCount);
  const aggregated = [];

  for (let i = 0; i < candles.length; i += groupSize) {
    const group = candles.slice(i, i + groupSize);
    const aggregated_Candle = {
      timestamp: group[0].timestamp,
      open: group[0].open,
      high: Math.max(...group.map(c => c.high)),
      low: Math.min(...group.map(c => c.low)),
      close: group[group.length - 1].close,
      volume: group.reduce((sum, c) => sum + c.volume, 0)
    };
    aggregated.push(aggregated_Candle);
  }

  return aggregated;
}

export function calculateRSI(candles, period = 14) {
  if (candles.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = candles.length - period; i < candles.length; i++) {
    const change = candles[i].close - candles[i - 1].close;
    if (change > 0) gains += change;
    else losses += -change;
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  
  return 100 - (100 / (1 + rs));
}

export function calculateSMA(candles, period) {
  if (candles.length < period) return null;
  
  let sum = 0;
  for (let i = candles.length - period; i < candles.length; i++) {
    sum += candles[i].close;
  }
  
  return sum / period;
}

export function calculateVolatility(candles, period = 20) {
  if (candles.length < period) return 0;

  const closes = candles.slice(-period).map(c => c.close);
  const mean = closes.reduce((a, b) => a + b) / period;
  const variance = closes.reduce((sum, close) => sum + Math.pow(close - mean, 2), 0) / period;
  
  return Math.sqrt(variance);
}
