export class Renderer {
  constructor(canvas, ctx) {
    this.canvas = canvas;
    this.ctx = ctx;
  }

  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  resize() {
    this.canvas.width = this.canvas.clientWidth;
    this.canvas.height = this.canvas.clientHeight;
  }

  drawGrid(width, height, scales) {
    const ctx = this.ctx;
    ctx.strokeStyle = "#1c1c28";
    ctx.lineWidth = 1;

    const stepX = 80;
    const stepY = 60;

    for (let x = 0; x < width; x += stepX) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    for (let y = 0; y < height; y += stepY) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }

  drawPriceLadder(scales, height) {
    const ctx = this.ctx;
    ctx.fillStyle = "#7f7fa0";
    ctx.font = "11px Arial";

    const steps = 8;
    const range = scales.max - scales.min || 1;
    const step = range / steps;

    for (let i = 0; i <= steps; i++) {
      const price = scales.min + step * i;
      const y = scales.priceToY(price, height);
      ctx.fillText(price.toFixed(2), 5, y - 2);
    }
  }

  drawCandles(candles, scales, width, height) {
    const ctx = this.ctx;
    const candleWidth = 6;
    const gap = 2;

    const maxVisible = Math.floor(width / (candleWidth + gap));
    const slice = candles.slice(-maxVisible);

    slice.forEach((c, i) => {
      const x = i * (candleWidth + gap);

      const openY = scales.priceToY(c.open, height);
      const closeY = scales.priceToY(c.close, height);
      const highY = scales.priceToY(c.high, height);
      const lowY = scales.priceToY(c.low, height);

      const bullish = c.close >= c.open;
      ctx.strokeStyle = bullish ? "#3ddc97" : "#ff4b5c";

      ctx.beginPath();
      ctx.moveTo(x + candleWidth / 2, highY);
      ctx.lineTo(x + candleWidth / 2, lowY);
      ctx.stroke();

      ctx.fillStyle = bullish ? "#3ddc97" : "#ff4b5c";
      const bodyTop = Math.min(openY, closeY);
      const bodyHeight = Math.max(2, Math.abs(closeY - openY));
      ctx.fillRect(x, bodyTop, candleWidth, bodyHeight);
    });
  }

  drawTimeAxis(candles, width, height) {
    const ctx = this.ctx;
    ctx.fillStyle = "#7f7fa0";
    ctx.font = "11px Arial";

    if (candles.length === 0) return;

    const maxVisible = Math.floor(width / 8);
    const slice = candles.slice(-maxVisible);

    const step = Math.max(1, Math.floor(slice.length / 6));

    slice.forEach((c, i) => {
      if (i % step !== 0) return;
      const ts = new Date(c.timestamp);
      const label = ts.toISOString().split("T")[1].split(".")[0];
      const x = i * 8;
      ctx.fillText(label, x, height - 5);
    });
  }

  drawPriceLine(candles, scales, width, height) {
    if (candles.length === 0) return;

    const ctx = this.ctx;
    const last = candles[candles.length - 1];

    const y = scales.priceToY(last.close, height);

    ctx.strokeStyle = "#ffffff55";
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  drawCrosshairAndTooltip(candles, scales, width, height, mouse) {
    if (!mouse.inside) return;

    const ctx = this.ctx;

    ctx.strokeStyle = "#555a";
    ctx.beginPath();
    ctx.moveTo(mouse.x, 0);
    ctx.lineTo(mouse.x, height);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, mouse.y);
    ctx.lineTo(width, mouse.y);
    ctx.stroke();
  }
}
