import { DataFeed } from './datafeed.js';
import { Renderer } from './renderer.js';
import { Scales } from './scales.js';
import { Viewport } from './viewport.js';
import { setupInteractions } from './interactions.js';

import { StructuralEngine } from '../engines/structural.js';
import { EnvironmentEngine } from '../engines/environment.js';
import { ExecutionEngine } from '../engines/execution.js';
import { OperatorEngine } from '../engines/operator.js';
import { TriMarketEngine } from '../engines/trimarket.js';

export class ChartEngine {
  constructor(canvasId = 'chart') {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');

    this.dataFeed = new DataFeed();
    this.renderer = new Renderer(this.canvas, this.ctx);
    this.scales = new Scales();
    this.viewport = new Viewport();

    this.structural = new StructuralEngine();
    this.environment = new EnvironmentEngine();
    this.execution = new ExecutionEngine();
    this.operator = new OperatorEngine();
    this.trimarket = new TriMarketEngine();

    this.candles = [];
    this.currentTimeframe = '1s';
    this.mode = 'historical';

    this.animationFrameId = null;
    this.lastRenderTime = 0;
    this.targetFPS = 60;
    this.renderInterval = 1000 / this.targetFPS;

    this.mouse = { x: 0, y: 0, inside: false };

    this.resizeCanvas();
    window.addEventListener('resize', () => {
      this.resizeCanvas();
      this.renderer.resize();
      this.viewport.fitCandles(this.candles, this.canvas.clientWidth);
    });

    this.setupUI();
    setupInteractions(this);

    this.start();
  }

  setupUI() {
    const tfSelect = document.getElementById('timeframe-select');
    tfSelect.addEventListener('change', () => {
      this.setTimeframe(tfSelect.value);
    });

    const modeSelect = document.getElementById('mode-select');
    const status = document.getElementById('live-status');

    modeSelect.addEventListener('change', () => {
      this.mode = modeSelect.value;

      if (this.mode === 'historical') {
        this.dataFeed.disableLive();
        status.textContent = 'Mode: Historical';
        this.candles = [];
        this.dataFeed.lastCandles = {};
        this.loadHistoricalData();
      }

      if (this.mode === 'sim') {
        this.dataFeed.disableLive();
        status.textContent = 'Mode: SIM';
        this.candles = [];
        this.dataFeed.lastCandles = {};
      }

      if (this.mode === 'live') {
        this.dataFeed.enableLive();
        status.textContent = 'Mode: LIVE (Coinbase)';
        this.candles = [];
        this.dataFeed.lastCandles = {};
      }
    });
  }

  resizeCanvas() {
    const container = this.canvas.parentElement;
    this.canvas.style.width = `${container.clientWidth}px`;
    this.canvas.style.height = `${container.clientHeight}px`;
    this.canvas.width = container.clientWidth;
    this.canvas.height = container.clientHeight;
  }

  start() {
    this.loadHistoricalData();
    requestAnimationFrame(this.animate);
  }

  async loadHistoricalData() {
    try {
      const data = await this.dataFeed.fetchHistoricalData(this.currentTimeframe);
      this.candles = data;

      this.viewport.fitCandles(this.candles, this.canvas.clientWidth);

      const visible = this.viewport.getVisibleCandles(this.candles);
      this.scales.updateScales(visible.length > 0 ? visible : this.candles);
    } catch (error) {
      console.error('Failed to load historical data:', error);
    }
  }

  setTimeframe(tf) {
    this.currentTimeframe = tf;
    this.candles = [];

    if (this.mode === 'historical') {
      this.loadHistoricalData();
    } else {
      this.dataFeed.lastCandles = {};
    }
  }

  animate = (timestamp) => {
    if (!this.lastRenderTime) this.lastRenderTime = timestamp;
    const delta = timestamp - this.lastRenderTime;

    if (delta >= this.renderInterval) {
      if (this.mode === 'live') {
        const newCandle = this.dataFeed.getLatestCandle(this.currentTimeframe);
        if (
          newCandle &&
          (this.candles.length === 0 ||
            newCandle.timestamp !== this.candles[this.candles.length - 1].timestamp)
        ) {
          this.candles.push(newCandle);
          this.viewport.autoScrollToLatest(this.candles);
        }
      }

      if (this.mode === 'sim') {
        const tfMs = this.dataFeed.getTF(this.currentTimeframe);
        const period = Math.floor(Date.now() / tfMs) * tfMs;
        const newCandle = this.dataFeed.getSimBTC(this.currentTimeframe, period, tfMs);

        if (
          newCandle &&
          (this.candles.length === 0 ||
            newCandle.timestamp !== this.candles[this.candles.length - 1].timestamp)
        ) {
          this.candles.push(newCandle);
          this.viewport.autoScrollToLatest(this.candles);
        }
      }

      this.viewport.update(delta);

      const visible = this.viewport.getVisibleCandles(this.candles);
      const scaled = visible.length > 0 ? visible : this.candles;

      this.scales.updateScales(scaled);

      const width = this.canvas.clientWidth;
      const height = this.canvas.clientHeight;

      this.renderer.clear();
      this.renderer.drawGrid(width, height, this.scales);
      this.renderer.drawPriceLadder(this.scales, height);
      this.renderer.drawCandles(scaled, this.scales, width, height);
      this.renderer.drawTimeAxis(scaled, width, height);
      this.renderer.drawPriceLine(scaled, this.scales, width, height);
      this.renderer.drawCrosshairAndTooltip(
        scaled,
        this.scales,
        width,
        height,
        this.mouse
      );

      this.updateEngines();

      this.lastRenderTime = timestamp;
    }

    this.animationFrameId = requestAnimationFrame(this.animate);
  };

  updateEngines() {
    if (this.candles.length === 0) return;

    this.structural.update(this.candles);
    this.environment.update(this.candles);
    this.execution.update(this.candles);

    const tri = this.dataFeed.getTriMarketSnapshot(this.currentTimeframe);
    this.trimarket.update(tri);

    this.operator.update(
      this.candles,
      this.structural,
      this.environment,
      this.execution,
      this.trimarket
    );
  }

  stop() {
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.chartEngine = new ChartEngine('chart');
});
