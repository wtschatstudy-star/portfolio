export function setupInteractions(engine) {
  const canvas = engine.canvas;

  canvas.addEventListener("mousemove", (e) => {
    const rect = canvas.getBoundingClientRect();
    engine.mouse.x = e.clientX - rect.left;
    engine.mouse.y = e.clientY - rect.top;
    engine.mouse.inside = true;
  });

  canvas.addEventListener("mouseleave", () => {
    engine.mouse.inside = false;
  });
}
