export class DataFeed {
  constructor() {
    this.assets = {
      BTC: this.createAssetState(42000, 1.0),
      ETH: this.createAssetState(2200, 1.6),
      SPX: this.createAssetState(4800, 0.3),
      DXY: this.createAssetState(103, 0.15),
    };

    this.liveEnabled = false;
    this.livePrice = null;
    this.liveSocket = null;

    this.lastCandles = {};
  }

  createAssetState(basePrice, beta) {
    return {
      basePrice,
      currentPrice: basePrice,
      beta,
      volatility: 0.002,
      volCycle: 0,
      trendCycle: 0,
      regime: 'RANGE',
      regimeTimer: 0,
      trendBias: 0,
      cascadeActive: false,
      cascadeDirection: 0,
      cascadeStepsLeft: 0,
      macroActive: false,
      macroStrength: 0,
      macroDirection: 0,
      macroDecay: 0,
      lastCandles: {},
    };
  }

  enableLive() {
    if (this.liveSocket) return;

    this.liveEnabled = true;

    this.liveSocket = new WebSocket("wss://ws-feed.exchange.coinbase.com");

    this.liveSocket.onopen = () => {
      this.liveSocket.send(JSON.stringify({
        type: "subscribe",
        product_ids: ["BTC-USD"],
        channels: ["ticker"]
      }));
    };

    this.liveSocket.onmessage = (msg) => {
      try {
        const data = JSON.parse(msg.data);
        if (data.type === "ticker" && data.price) {
          this.livePrice = parseFloat(data.price);
        }
      } catch (e) {}
    };

    this.liveSocket.onclose = () => {
      this.liveSocket = null;
      this.liveEnabled = false;
    };
  }

  disableLive() {
    this.liveEnabled = false;
    if (this.liveSocket) {
      this.liveSocket.close();
      this.liveSocket = null;
    }
  }

  async fetchHistoricalData(tf) {
    const count = 200;
    const tfMs = this.getTF(tf);
    const now = Date.now();

    const candles = [];

    const s = this.assets.BTC;
    s.currentPrice = s.basePrice;

    for (let i = count; i > 0; i--) {
      const ts = now - i * tfMs;
      const candle = this.generateAssetCandle('BTC', ts, tfMs);
      candles.push(candle);
    }

    return candles;
  }

  getLatestCandle(tf) {
    const tfMs = this.getTF(tf);
    const now = Date.now();
    const period = Math.floor(now / tfMs) * tfMs;

    if (!this.liveEnabled || this.livePrice === null) {
      return this.getSimBTC(tf, period, tfMs);
    }

    const price = this.livePrice;
    const last = this.lastCandles[tf];

    if (last && last.timestamp === period) {
      last.close = price;
      last.high = Math.max(last.high, price);
      last.low = Math.min(last.low, price);
      return last;
    }

    const candle = {
      timestamp: period,
      open: price,
      high: price,
      low: price,
      close: price,
      volume: 0,
    };

    this.lastCandles[tf] = candle;
    return candle;
  }

  getSimBTC(tf, period, tfMs) {
    const last = this.lastCandles[tf];

    if (last && last.timestamp === period) {
      const updated = this.extendAssetCandle('BTC', last, tfMs);
      this.lastCandles[tf] = updated;
      return updated;
    }

    const candle = this.generateAssetCandle('BTC', period, tfMs);
    this.lastCandles[tf] = candle;
    return candle;
  }

  getTriMarketSnapshot(tf) {
    const tfMs = this.getTF(tf);
    const now = Date.now();
    const period = Math.floor(now / tfMs) * tfMs;

    const symbols = ['BTC', 'ETH', 'SPX', 'DXY'];
    const snapshot = {};

    for (const sym of symbols) {
      const state = this.assets[sym];
      const last = state.lastCandles[tf];

      if (last && last.timestamp === period) {
        snapshot[sym.toLowerCase()] = this.extendAssetCandle(sym, last, tfMs);
      } else {
        const candle = this.generateAssetCandle(sym, period, tfMs);
        state.lastCandles[tf] = candle;
        snapshot[sym.toLowerCase()] = candle;
      }
    }

    return snapshot;
  }

  generateAssetCandle(symbol, timestamp, tfMs) {
    const state = this.assets[symbol];

    let open = state.currentPrice;
    let high = open;
    let low = open;
    let close = open;

    for (let i = 0; i < 4; i++) {
      close = this.simulatePriceStep(state, tfMs / 4);
      if (close > high) high = close;
      if (close < low) low = close;
    }

    const volumeBase = symbol === 'BTC' ? 300000 : symbol === 'ETH' ? 200000 : 150000;
    const volume = Math.floor(volumeBase + Math.random() * volumeBase);

    return { timestamp, open, high, low, close, volume, symbol };
  }

  extendAssetCandle(symbol, candle, tfMs) {
    const state = this.assets[symbol];

    let close = candle.close;
    let high = candle.high;
    let low = candle.low;

    for (let i = 0; i < 2; i++) {
      close = this.simulatePriceStep(state, tfMs / 2);
      if (close > high) high = close;
      if (close < low) low = close;
    }

    return {
      ...candle,
      high,
      low,
      close,
      volume: candle.volume + Math.floor(Math.random() * 50000),
    };
  }

  simulatePriceStep(state, dtMs) {
    const dt = dtMs / 60000;

    // Volatility cycle (slow sine)
    state.volCycle += dt * 0.1;
    const volFactor = 1 + 0.8 * Math.sin(state.volCycle);

    // Trend cycle (slow bias)
    state.trendCycle += dt * 0.05;
    state.trendBias = 0.0003 * Math.sin(state.trendCycle);

    // Regime switching timer
    state.regimeTimer -= dtMs;
    if (state.regimeTimer <= 0) {
      const r = Math.random();
      if (r < 0.4) state.regime = 'RANGE';
      else if (r < 0.7) state.regime = 'TREND_UP';
      else state.regime = 'TREND_DOWN';
      state.regimeTimer = 60000 + Math.random() * 120000;
    }

    let regimeDrift = 0;
    if (state.regime === 'TREND_UP') regimeDrift = 0.0005 * state.currentPrice;
    if (state.regime === 'TREND_DOWN') regimeDrift = -0.0005 * state.currentPrice;

    // Macro shock
    if (!state.macroActive && Math.random() < 0.0005) {
      state.macroActive = true;
      state.macroDirection = Math.random() < 0.5 ? -1 : 1;
      state.macroStrength = state.currentPrice * (0.003 + Math.random() * 0.007);
      state.macroDecay = 0.95 + Math.random() * 0.03;
    }

    let macroMove = 0;
    if (state.macroActive) {
      macroMove = state.macroDirection * state.macroStrength * dt;
      state.macroStrength *= state.macroDecay;
      if (state.macroStrength < state.currentPrice * 0.0005) {
        state.macroActive = false;
      }
    }

    // Cascade
    if (!state.cascadeActive && Math.random() < 0.0004) {
      state.cascadeActive = true;
      state.cascadeDirection = Math.random() < 0.5 ? -1 : 1;
      state.cascadeStepsLeft = 5 + Math.floor(Math.random() * 6);
    }

    let cascadeMove = 0;
    if (state.cascadeActive && state.cascadeStepsLeft > 0) {
      cascadeMove =
        state.cascadeDirection *
        state.currentPrice *
        state.volatility *
        4 *
        Math.sqrt(dt);
      state.cascadeStepsLeft -= 1;
      if (state.cascadeStepsLeft <= 0) state.cascadeActive = false;
    }

    const randomShock =
      (Math.random() - 0.5) *
      state.currentPrice *
      state.volatility *
      volFactor *
      Math.sqrt(dt);

    const meanRevert =
      (state.basePrice - state.currentPrice) *
      0.00002 *
      state.currentPrice;

    const move =
      randomShock +
      meanRevert +
      regimeDrift * dt +
      state.trendBias * state.currentPrice * dt +
      macroMove +
      cascadeMove;

    state.currentPrice += move;

    return state.currentPrice;
  }

  getTF(tf) {
    return {
      "1s": 1000,
      "5s": 5000,
      "10s": 10000,
      "30s": 30000,
      "1m": 60000,
      "5m": 300000,
      "15m": 900000,
      "30m": 1800000,
      "1h": 3600000,
    }[tf] || 1000;
  }
}
