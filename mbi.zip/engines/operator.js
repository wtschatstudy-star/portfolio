export class OperatorEngine {
  constructor() {
    this.state = "Neutral";
    this.permission = "OK";
    this.globalRegime = "Normal";
  }

  update(candles, structural, environment, execution, trimarket) {
    if (execution.rsi > 70) this.state = "Overbought";
    else if (execution.rsi < 30) this.state = "Oversold";
    else this.state = "Neutral";

    if (environment.regime === "High Vol" && trimarket.regime === "High Influence") {
      this.globalRegime = "Danger";
    } else if (environment.regime === "Calm" && trimarket.regime === "Low Influence") {
      this.globalRegime = "Smooth";
    } else {
      this.globalRegime = "Normal";
    }

    this.permission = "OK";
  }
}
