export class EnvironmentEngine {
  constructor() {
    this.liquidity = 0;
    this.volatility = 0;
    this.regime = "Neutral";
  }

  update(candles) {
    if (candles.length < 2) return;

    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];

    this.volatility = Math.abs(last.close - prev.close);
    this.liquidity = last.volume;

    if (this.volatility > 60) this.regime = "High Vol";
    else if (this.volatility < 20) this.regime = "Calm";
    else this.regime = "Normal";
  }
}
