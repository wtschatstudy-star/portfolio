export class StructuralEngine {
  constructor() {
    this.drift = 0;
    this.tension = 0;
    this.symmetry = 0;
    this.structMACD = "Neutral";
  }

  update(candles) {
    if (candles.length < 2) return;

    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];

    this.drift = last.close - prev.close;
    this.tension = Math.abs(last.high - last.low);
    this.symmetry = (last.close - last.open) / (last.high - last.low + 1e-6);

    if (this.drift > 0 && this.symmetry > 0) this.structMACD = "Bull";
    else if (this.drift < 0 && this.symmetry < 0) this.structMACD = "Bear";
    else this.structMACD = "Neutral";
  }
}
