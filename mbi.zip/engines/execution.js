export class ExecutionEngine {
  constructor() {
    this.rsi = 50;
    this.macdState = "Neutral";
  }

  update(candles) {
    if (candles.length < 14) return;

    const closes = candles.slice(-14).map(c => c.close);
    const gains = [];
    const losses = [];

    for (let i = 1; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff >= 0) gains.push(diff);
      else losses.push(-diff);
    }

    const avgGain = gains.reduce((a, b) => a + b, 0) / 14 || 0.0001;
    const avgLoss = losses.reduce((a, b) => a + b, 0) / 14 || 0.0001;

    const rs = avgGain / avgLoss;
    this.rsi = 100 - 100 / (1 + rs);

    if (this.rsi > 60) this.macdState = "Bull";
    else if (this.rsi < 40) this.macdState = "Bear";
    else this.macdState = "Neutral";
  }
}
