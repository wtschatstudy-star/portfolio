export class TriMarketEngine {
  constructor() {
    this.score = 0;
    this.regime = "Low Influence";
    this.correlations = {
      eth: "...",
      spx: "...",
      dxy: "..."
    };
    this.bleed = 0;
  }

  update(snapshot) {
    const btc = snapshot.btc;
    const eth = snapshot.eth;
    const spx = snapshot.spx;
    const dxy = snapshot.dxy;

    const r_btc = btc.close - btc.open;
    const r_eth = eth.close - eth.open;
    const r_spx = spx.close - spx.open;
    const r_dxy = dxy.close - dxy.open;

    const corr_btc_eth = r_btc * r_eth > 0 ? "Aligned" : "Diverging";
    const corr_btc_spx = r_btc * r_spx > 0 ? "Risk-On" : "Risk-Off";
    const corr_btc_dxy = r_btc * r_dxy < 0 ? "Normal" : "Inverted";

    this.correlations = {
      eth: corr_btc_eth,
      spx: corr_btc_spx,
      dxy: corr_btc_dxy,
    };

    let bleed = 0;
    bleed += r_eth * 0.6;
    bleed += r_spx * 0.3;
    bleed -= r_dxy * 0.4;
    this.bleed = bleed.toFixed(3);

    if (Math.abs(bleed) > Math.abs(btc.close) * 0.004) {
      this.regime = "High Influence";
    } else if (Math.abs(bleed) > Math.abs(btc.close) * 0.002) {
      this.regime = "Moderate";
    } else {
      this.regime = "Low Influence";
    }

    let score = 0;
    if (corr_btc_eth === "Aligned") score += 1;
    if (corr_btc_spx === "Risk-On") score += 1;
    if (corr_btc_dxy === "Normal") score += 1;
    this.score = score;
  }
}
